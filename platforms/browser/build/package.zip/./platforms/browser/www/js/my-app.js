// Initialize app
var myApp = new Framework7({
  material: true,
  cache:true
});

// If we need to use custom DOM library, let's save it to $$ variable:
var $$ = Dom7;


// Add view
var mainView = myApp.addView('.view-main', {
  // Because we want to use dynamic navbar, we need to enable it for this view:
  dynamicNavbar: true
});

// Handle Cordova Device Ready Event
$$(document).on('deviceready', function() {
  console.log("Device is ready!");
  StatusBar.backgroundColorByHexString("#2196f3");
});

function exitPrompt(){
  myApp.confirm('Are you sure you want to exit?', "", function () {
    navigator.app.clearHistory();
    navigator.app.exitApp();
  });
}

function goBack(){
  var mainView = myApp.addView('.view-main');
  mainView.router.loadPage('index.html');
}

myApp.onPageInit('home', function () {
  document.removeEventListener("backbutton", goBack, false);
  document.addEventListener("backbutton", exitPrompt, false);
})

//Login screen methods inside this
myApp.onPageInit('login-with-email', function () {
  myApp.loginScreen();

  //go back button in sign in with email view
  $$('.close-login-screen').on('click', function () {
    var mainView = myApp.addView('.view-main');
    mainView.router.back();
    myApp.closeModal('.login-screen');
  });

  //sign in with email button click method
  $$('.login-to-main-view').on('click', function () {
    console.log("loading tab-view");
    var mainView = myApp.addView('.view-main');
    mainView.router.loadPage('homeTabView.html');
    myApp.closeModal('.login-screen');
  });

  $$(document).on('deviceready', function() {
    document.removeEventListener("backbutton", exitPrompt, false);
    document.addEventListener("backbutton", goBack, false);
    console.log("Device is ready!");
  });
})

myApp.onPageInit('tabs-main', function () {
  var myApp = new Framework7({
    swipePanel: 'left',
    swipePanelActiveArea: 20,
    cache:true
  });

  console.log(myApp);

  console.log("tabs-main entered successfully");
  $$(document).on('deviceready', function() {
    document.removeEventListener("backbutton", goBack, false);
    document.addEventListener("backbutton", exitPrompt, false);
  });

  $$('.open-left-panel').on('click', function (e) {
    console.log("opening left panel...");
    myApp.openPanel('left');
  });

  var ptrContent = $$('.pull-to-refresh-content');
  ptrContent.on('refresh', function (e) {
    myApp.pullToRefreshDone(); // After we refreshed page content, we need to reset pull to refresh component to let user pull it again:
  });

  // Loading flag
  var loading = false;

  // Last loaded index

  // Max items to load
  var maxItems = 60;

  // Append items per load
  var itemsPerLoad = 1;

  // Attach 'infinite' event handler
  $$('.infinite-scroll').on('infinite', function () {
    // Exit, if loading in progress
    if (loading) return;
    // Set loading flag
    loading = true;

    // Emulate 1s loading
    setTimeout(function () {
      // Generate new items HTML
      var html = '';
      for (var i = 0; i < itemsPerLoad; i++) {
        html += '<div class="card card-header-pic">' +
        '<div style="background-image:url(http://lorempixel.com/1000/600/nature/3/)" valign="bottom" class="card-header color-white no-border">Journey To Mountains</div>' +
        '<div class="card-content">' +
        '<div class="card-content-inner">' +
        '<p class="color-gray">Posted on January 21, 2015</p>' +
        '<p>Card number 1</p>' +
        '</div>' +
        '</div>' +
        '<div class="card-footer">' +
        '<a href="#" class="link">Like</a>' +
        '<a href="#" class="link">Read more</a>' +
        '</div>' +
        '</div>';
      }

      // Nothing more to load, detach infinite scroll events to prevent unnecessary loadings
      myApp.detachInfiniteScroll($$('.infinite-scroll'));
      // Remove preloader
      $$('.infinite-scroll-preloader').remove();

      // Append new items
      $$('.infinite-scroll').append(html);

      // Reset loading flag
      loading = false;
    }, 1000);
  });
})

//wizard page
myApp.onPageInit('wizard', function (page) {
  StatusBar.backgroundColorByHexString("#222");

  document.removeEventListener("backbutton", goBack, false);
  document.addEventListener("backbutton", exitPrompt, false);

  var myList = myApp.virtualList('.list-block.virtual-list', {
    // Array with items data
    items: [
      {
        title: 'Action',
      },
      {
        title: 'Animation',
      },
      {
        title: 'Comedy',
      },
      {
        title: 'Documentary',
      },
      {
        title: 'Fantasy',
      },
      {
        title: 'Horror',
      },
      {
        title: 'Romance',
      },
      {
        title: 'Sci-Fi',
      },
      {
        title: 'Thriller',
      }
    ],
    // Template 7 template to render each item
    template: '<li>' +
      '<label class="label-checkbox item-content">' +
        '<input type="checkbox" name="my-checkbox" value="Books" >' +
        '<div class="item-media">' +
          '<i class="icon icon-form-checkbox"></i>' +
        '</div>' +
        '<div class="item-inner">' +
          '<div class="item-title">{{title}}</div>' +
        '</div>' +
      '</label>' +
    '</li>'
  });
})

myApp.onPageInit('wizard-keywords', function (page) {
  console.log("second wizard page");
  StatusBar.backgroundColorByHexString("#222");
})
